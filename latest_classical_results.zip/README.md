# Latest completed classical OOF results

This package contains existing artifacts only. No model was trained, no inference
was run, no predictions were regenerated, and no TCP/DNS evaluation was performed
while creating it.

## Selection

The selected runs are the completed 2,425-row, 160-positive, 11-family classical
suite used by the current report. All use the common `engineered_tfidf` feature
configuration and three-fold `StratifiedGroupKFold` validation with draft revisions
grouped by family. These are the current report's directly comparable logistic
regression, Linear SVM, and random-forest configurations. Their artifact timestamps
are 2026-10-20 22:46:05 in this checkout; timestamps are descriptive, while the
manifests and metrics establish run identity.

| Packaged directory | Model | Feature configuration | Rows / positives | Folds | Score meaning | Threshold | Original artifact path |
|---|---|---|---:|---:|---|---:|---|
| `logistic_regression_engineered_tfidf/` | Class-balanced L1 logistic regression, C=0.5 | 25 engineered features + word unigram/bigram TF-IDF | 2,425 / 160 | 3 | `oof_probability_yes`: positive-class probability from each held-out fold | 0.5 | `results/ML/v2_engineered_tfidf/` |
| `linear_svm_engineered_tfidf/` | Balanced LinearSVC | Engineered features + word unigram/bigram TF-IDF | 2,425 / 160 | 3 | `oof_score_yes`: sigmoid of raw SVM decision margin; 0.5 maps to margin 0 and is not a calibrated probability | 0.5 | `results/ML/additional_classifiers/linear_svm/engineered_tfidf/` |
| `random_forest_engineered_tfidf/` | Random forest, 300 trees, balanced-subsample weights | Engineered features + word unigram/bigram TF-IDF | 2,425 / 160 | 3 | `oof_score_yes`: positive-class `predict_proba` output | 0.5 | `results/ML/additional_classifiers/random_forest/engineered_tfidf/` |

Each model directory contains byte-for-byte copies of:

- `oof_predictions.csv`
- `metrics.json`
- `manifest.json`
- `fold_metrics.csv`

`summary.csv` extracts only metrics already saved in `metrics.json`. It does not
recompute metrics or predictions.

## OOF schema limitations

The saved OOF files contain `item_id`, `document`, `final_label`, a
`validation_group`, and a score. They do **not** contain `record_id`, an explicit
predicted-label column, or a per-row validation-fold column. `validation_group`
is the draft-family grouping key and must not be mistaken for a fold number.
`fold_metrics.csv` records fold-level aggregate counts but cannot map an individual
OOF row back to its fold. These unavailable fields are marked `missing` in the
package summary rather than reconstructed.

The saved pooled metrics contain AP, ROC-AUC, precision, recall, F1, and F2 at
threshold 0.5. They do not contain pooled TP, FP, TN, or FN counts, so those fields
are also marked `missing`. Historical metric JSON uses the key `pr_auc` for the
stepwise average-precision value; `summary.csv` labels it AP.

## Annotation-source verification

All three manifests name a file ending in
`results/annotation/final_annotation_ready.csv` and pin the same source SHA-256:

`66d9013d50ad0cb8a66c9523c77624ae388a3dc24aa133d7975a4f5730aa27f0`

The current local file at that repository path has SHA-256:

`8ffa654c2c405dd3eef72901c600f1ef3823e6dbff663020bb824c57ff65bdbf`

Therefore the run manifests refer to an earlier or otherwise different 2,425-row,
160-positive snapshot. The original manifest paths are Linux paths under
`/media/yahya/...`; the exact `66d901...` source CSV was not found at the current
repository path. Cohort counts match, but exact row/field identity with the current
`final_annotation_ready.csv` is **not verified**. This is a provenance mismatch,
not evidence that the saved OOF outputs are invalid for their own pinned snapshot.

No standalone `run_config.json` exists for these selected runs. Model and feature
configuration is embedded in `metrics.json`, with source and score provenance in
`manifest.json`.
